var _0xa1b8=['exports','/package.json','version'];(function(_0x47fdcd,_0x3952cc){var _0x1ebd76=function(_0x3f3c4e){while(--_0x3f3c4e){_0x47fdcd['push'](_0x47fdcd['shift']());}};_0x1ebd76(++_0x3952cc);}(_0xa1b8,0x138));var _0x29e5=function(_0x32a9ef,_0x42fdf1){_0x32a9ef=_0x32a9ef-0x0;var _0x53ed9f=_0xa1b8[_0x32a9ef];return _0x53ed9f;};/**
 * Copyright (c) 2015-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
'use strict';module[_0x29e5('0x0')]=function getCacheIdentifier(_0x471298,_0x403600){let _0x3fc36c=_0x471298==null?'':_0x471298['toString']();for(const _0x3c89aa of _0x403600){_0x3fc36c+=':'+_0x3c89aa+'@';try{_0x3fc36c+=require(_0x3c89aa+_0x29e5('0x1'))[_0x29e5('0x2')];}catch(_0x512937){}}return _0x3fc36c;};