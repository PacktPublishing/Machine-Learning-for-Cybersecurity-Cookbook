var _0x24c9=['../common','maxTickDepth','error','tick\x20','nextTick'];(function(_0xaa0bb8,_0x4a023a){var _0x5d54d9=function(_0x350741){while(--_0x350741){_0xaa0bb8['push'](_0xaa0bb8['shift']());}};_0x5d54d9(++_0x4a023a);}(_0x24c9,0x1ae));var _0x27cf=function(_0x101b8f,_0xcd7c6f){_0x101b8f=_0x101b8f-0x0;var _0x27941a=_0x24c9[_0x101b8f];return _0x27941a;};// Copyright Joyent, Inc. and other Node contributors.
//
// Permission is hereby granted, free of charge, to any person obtaining a
// copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to permit
// persons to whom the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice shall be included
// in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
// OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
// NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
// USE OR OTHER DEALINGS IN THE SOFTWARE.
'use strict';require(_0x27cf('0x0'));process[_0x27cf('0x1')]=0xa;let i=0x14;process['nextTick'](function f(){console[_0x27cf('0x2')](_0x27cf('0x3')+i);if(i-->0x0)process[_0x27cf('0x4')](f);});