var _0xdc72=['unmock','createPerformanceLogger','GlobalPerformanceLogger','exports'];(function(_0x485124,_0x2dc93c){var _0x23d0da=function(_0x2f876a){while(--_0x2f876a){_0x485124['push'](_0x485124['shift']());}};_0x23d0da(++_0x2dc93c);}(_0xdc72,0xcc));var _0x20e6=function(_0x3ace0e,_0x176c26){_0x3ace0e=_0x3ace0e-0x0;var _0x649b59=_0xdc72[_0x3ace0e];return _0x649b59;};/**
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 *
 * @format
 */
'use strict';const GlobalPerformanceLogger=jest[_0x20e6('0x0')](_0x20e6('0x1'))['genMockFromModule'](_0x20e6('0x2'));module[_0x20e6('0x3')]=GlobalPerformanceLogger;