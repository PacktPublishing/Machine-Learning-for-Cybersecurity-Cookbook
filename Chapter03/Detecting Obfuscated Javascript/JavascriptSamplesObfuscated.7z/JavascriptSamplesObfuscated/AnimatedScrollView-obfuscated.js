var _0x5581=['ScrollView'];(function(_0x1bf551,_0x38ba0f){var _0x30180a=function(_0x501f0a){while(--_0x501f0a){_0x1bf551['push'](_0x1bf551['shift']());}};_0x30180a(++_0x38ba0f);}(_0x5581,0x91));var _0x47e3=function(_0x3b490c,_0xd9776c){_0x3b490c=_0x3b490c-0x0;var _0x1f50f1=_0x5581[_0x3b490c];return _0x1f50f1;};/**
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 *
 * @flow strict-local
 * @format
 */
'use strict';const ScrollView=require(_0x47e3('0x0'));const createAnimatedComponent=require('createAnimatedComponent');module['exports']=createAnimatedComponent(ScrollView);