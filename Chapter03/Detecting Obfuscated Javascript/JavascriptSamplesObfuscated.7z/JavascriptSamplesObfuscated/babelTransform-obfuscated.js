var _0x4d09=['babel-jest','createTransformer','resolve','babel-preset-react-app'];(function(_0xa9b7ba,_0x6ac66d){var _0x27c71c=function(_0x8b724e){while(--_0x8b724e){_0xa9b7ba['push'](_0xa9b7ba['shift']());}};_0x27c71c(++_0x6ac66d);}(_0x4d09,0x1ec));var _0x2775=function(_0x13ce4d,_0x286cd9){_0x13ce4d=_0x13ce4d-0x0;var _0x53ff6c=_0x4d09[_0x13ce4d];return _0x53ff6c;};// @remove-file-on-eject
/**
 * Copyright (c) 2014-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
'use strict';const babelJest=require(_0x2775('0x0'));module['exports']=babelJest[_0x2775('0x1')]({'presets':[require[_0x2775('0x2')](_0x2775('0x3'))],'babelrc':![],'configFile':![]});