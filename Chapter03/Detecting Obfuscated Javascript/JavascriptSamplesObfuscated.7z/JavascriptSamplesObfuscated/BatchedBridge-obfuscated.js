var _0x68a4=['__fbBatchedBridge','exports','MessageQueue','defineProperty'];(function(_0x3a611c,_0x6f1bc6){var _0x1b63f7=function(_0x3e25f4){while(--_0x3e25f4){_0x3a611c['push'](_0x3a611c['shift']());}};_0x1b63f7(++_0x6f1bc6);}(_0x68a4,0x6a));var _0x22e9=function(_0x32144b,_0x1abc98){_0x32144b=_0x32144b-0x0;var _0x1e701f=_0x68a4[_0x32144b];return _0x1e701f;};/**
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 *
 * @format
 * @flow strict-local
 */
'use strict';const MessageQueue=require(_0x22e9('0x0'));const BatchedBridge=new MessageQueue();Object[_0x22e9('0x1')](global,_0x22e9('0x2'),{'configurable':!![],'value':BatchedBridge});module[_0x22e9('0x3')]=BatchedBridge;