var _0x16ee=['../common','assert','error','Exiting\x20with\x20code='];(function(_0x56dde8,_0x97340e){var _0x541d44=function(_0x3160db){while(--_0x3160db){_0x56dde8['push'](_0x56dde8['shift']());}};_0x541d44(++_0x97340e);}(_0x16ee,0x164));var _0x238f=function(_0x1c1351,_0x5857c9){_0x1c1351=_0x1c1351-0x0;var _0x2bb679=_0x16ee[_0x1c1351];return _0x2bb679;};// Copyright Joyent, Inc. and other Node contributors.
//
// Permission is hereby granted, free of charge, to any person obtaining a
// copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to permit
// persons to whom the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice shall be included
// in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
// OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
// NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
// USE OR OTHER DEALINGS IN THE SOFTWARE.
'use strict';require(_0x238f('0x0'));const assert=require(_0x238f('0x1'));process['on']('exit',function(_0x3b0ac3){console[_0x238f('0x2')](_0x238f('0x3')+_0x3b0ac3);});assert['strictEqual'](0x1,0x2);