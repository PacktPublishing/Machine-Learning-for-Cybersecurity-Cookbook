var _0x168f=['random','toString','exports'];(function(_0x2699a9,_0x501e82){var _0x5b6c40=function(_0xa3de42){while(--_0xa3de42){_0x2699a9['push'](_0x2699a9['shift']());}};_0x5b6c40(++_0x501e82);}(_0x168f,0xcc));var _0x37e2=function(_0x5b7db1,_0x19265f){_0x5b7db1=_0x5b7db1-0x0;var _0x5e5f0e=_0x168f[_0x5b7db1];return _0x5e5f0e;};/**
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 *
 * @format
 */
/* eslint-disable no-bitwise */
'use strict';/**
 * Module that provides a function for creating a unique identifier.
 * The returned value does not conform to the GUID standard, but should
 * be globally unique in the context of the browser.
 */function guid(){return'f'+(Math[_0x37e2('0x0')]()*(0x1<<0x1e))[_0x37e2('0x1')](0x10)['replace']('.','');}module[_0x37e2('0x2')]=guid;