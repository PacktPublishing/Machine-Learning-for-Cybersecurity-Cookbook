var _0x5c7f=['promiseMethod','RemoteModule2','exports','remoteMethod'];(function(_0x19ba91,_0x5b9e7a){var _0x5b85ff=function(_0x547249){while(--_0x547249){_0x19ba91['push'](_0x19ba91['shift']());}};_0x5b85ff(++_0x5b9e7a);}(_0x5c7f,0xb7));var _0x201a=function(_0x4ecdb8,_0x61ad50){_0x4ecdb8=_0x4ecdb8-0x0;var _0x3fe4da=_0x5c7f[_0x4ecdb8];return _0x3fe4da;};/**
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 *
 * These don't actually exist anywhere in the code.
 *
 * @format
 */
'use strict';const remoteModulesConfig=[['RemoteModule1',null,[_0x201a('0x0'),_0x201a('0x1')],[]],[_0x201a('0x2'),null,[_0x201a('0x0'),_0x201a('0x1')],[]]];const MessageQueueTestConfig={'remoteModuleConfig':remoteModulesConfig};module[_0x201a('0x3')]=MessageQueueTestConfig;