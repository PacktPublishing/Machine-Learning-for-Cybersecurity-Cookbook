var _0x1735=['createAnimatedComponent'];(function(_0x54d00c,_0x37e49a){var _0x1e1b31=function(_0x2c9d23){while(--_0x2c9d23){_0x54d00c['push'](_0x54d00c['shift']());}};_0x1e1b31(++_0x37e49a);}(_0x1735,0x146));var _0x1880=function(_0xba1fab,_0x308b7a){_0xba1fab=_0xba1fab-0x0;var _0x21a191=_0x1735[_0xba1fab];return _0x21a191;};/**
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 *
 * @flow strict-local
 * @format
 */
'use strict';const View=require('View');const createAnimatedComponent=require(_0x1880('0x0'));module['exports']=createAnimatedComponent(View);