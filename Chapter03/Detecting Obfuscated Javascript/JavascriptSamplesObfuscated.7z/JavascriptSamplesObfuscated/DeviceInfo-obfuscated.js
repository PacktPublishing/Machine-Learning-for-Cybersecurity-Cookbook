var _0x2b4a=['exports','NativeModules','invariant','DeviceInfo\x20native\x20module\x20is\x20not\x20installed\x20correctly'];(function(_0x3de652,_0x3ff632){var _0x213d2a=function(_0x31f8f8){while(--_0x31f8f8){_0x3de652['push'](_0x3de652['shift']());}};_0x213d2a(++_0x3ff632);}(_0x2b4a,0x155));var _0x1659=function(_0xb2f106,_0x2585c2){_0xb2f106=_0xb2f106-0x0;var _0x4cde9f=_0x2b4a[_0xb2f106];return _0x4cde9f;};/**
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 *
 * @format
 * @flow strict-local
 */
'use strict';const DeviceInfo=require(_0x1659('0x0'))['DeviceInfo'];const invariant=require(_0x1659('0x1'));invariant(DeviceInfo,_0x1659('0x2'));module[_0x1659('0x3')]=DeviceInfo;