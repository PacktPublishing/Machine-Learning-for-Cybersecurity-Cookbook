var _0x5ed1=['createAnimatedComponent'];(function(_0x580489,_0x7c2650){var _0x2a496e=function(_0x4ce8ff){while(--_0x4ce8ff){_0x580489['push'](_0x580489['shift']());}};_0x2a496e(++_0x7c2650);}(_0x5ed1,0xac));var _0xff2d=function(_0x318fdf,_0x53965){_0x318fdf=_0x318fdf-0x0;var _0x3bfd38=_0x5ed1[_0x318fdf];return _0x3bfd38;};/**
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 *
 * @flow strict-local
 * @format
 */
'use strict';const SectionList=require('SectionList');const createAnimatedComponent=require(_0xff2d('0x0'));module['exports']=createAnimatedComponent(SectionList);