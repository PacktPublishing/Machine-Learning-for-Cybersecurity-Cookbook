var _0xb5a1=['exports','whatwg-fetch'];(function(_0x3bb5b5,_0x4f5087){var _0x39ee44=function(_0x48d677){while(--_0x48d677){_0x3bb5b5['push'](_0x3bb5b5['shift']());}};_0x39ee44(++_0x4f5087);}(_0xb5a1,0x157));var _0x5831=function(_0x393a82,_0x563d17){_0x393a82=_0x393a82-0x0;var _0x2a0143=_0xb5a1[_0x393a82];return _0x2a0143;};/**
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 *
 * @format
 */
/* globals Headers, Request, Response */
'use strict';const whatwg=require(_0x5831('0x0'));if(whatwg&&whatwg['fetch']){module['exports']=whatwg;}else{module[_0x5831('0x1')]={'fetch':fetch,'Headers':Headers,'Request':Request,'Response':Response};}