var _0x4f3b=['should\x20give\x20device\x20info','toHaveProperty','Dimensions','DeviceInfo'];(function(_0x39528e,_0x20e1ab){var _0x2d1fcb=function(_0x5d90e5){while(--_0x5d90e5){_0x39528e['push'](_0x39528e['shift']());}};_0x2d1fcb(++_0x20e1ab);}(_0x4f3b,0xab));var _0x5acb=function(_0xca6617,_0x48fe96){_0xca6617=_0xca6617-0x0;var _0x199b27=_0x4f3b[_0xca6617];return _0x199b27;};/**
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 *
 * @format
 * @emails oncall+react_native
 */
'use strict';describe(_0x5acb('0x0'),()=>{const _0x210949=require('DeviceInfo');it(_0x5acb('0x1'),()=>{expect(_0x210949)[_0x5acb('0x2')](_0x5acb('0x3'));});});