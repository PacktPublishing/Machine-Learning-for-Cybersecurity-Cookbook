#!/usr/bin/env node
require('./lib/cli.js');
