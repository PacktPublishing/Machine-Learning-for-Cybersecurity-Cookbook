import createRedirect from './createRedirect';

export default createRedirect('/');
