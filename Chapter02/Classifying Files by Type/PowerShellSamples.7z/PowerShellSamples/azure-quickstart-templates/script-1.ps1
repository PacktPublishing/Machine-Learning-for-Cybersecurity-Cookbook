# Insert code to fetch information to be returned, then write to stdout

# write an array delimiter before and after the data we want
Write-Host "#DATA#"
Write-Host "This is the droid you have been looking for..."
Write-Host "#DATA#"
