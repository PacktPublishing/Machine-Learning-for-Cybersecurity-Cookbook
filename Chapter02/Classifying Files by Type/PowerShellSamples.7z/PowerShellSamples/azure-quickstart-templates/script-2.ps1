param(
    [string] $Data
)

# This script can do whatever we want it to

Write-Host 'this is what we got from the previous script:'
Write-Host $Data
